package com.example.payment_service.service;

import java.util.Random;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.payment_service.entity.Payment;
import com.example.payment_service.repository.PayementRepository;

@Service
public class PaymentService {

	@Autowired
	private PayementRepository repository;

	public Payment doPayment(Payment payment) {
        payment.setPaymentStatus(paymentProcessing());
		payment.setTransactionId(UUID.randomUUID().toString());
		return repository.save(payment);
	}

	public String paymentProcessing() {
		return new Random().nextBoolean() ? "success" : "false";
	}

	public Payment findPaymentHistoryByOrderId(int orderId) {
		// TODO Auto-generated method stub
		return repository.findByOrderId(orderId);
	}

}
