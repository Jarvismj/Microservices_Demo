package com.example.order_service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.order_service.common.Payment;
import com.example.order_service.common.TransactionRequest;
import com.example.order_service.common.TransactionResponse;
import com.example.order_service.entity.Order;
import com.example.order_service.repository.OrderRepository;

@Service
public class OrderService {

	@Autowired
	private OrderRepository repository;

	@Autowired
	@LoadBalanced
	private RestTemplate restTemplate;

	public TransactionResponse saveOrder(TransactionRequest request) {
		String resp = " ";
		Order order = request.getOrder();
		Payment payment = request.getPayment();
		payment.setOrderId(order.getId());
		payment.setAmount(order.getPrice());
		Payment response = restTemplate.postForObject("http://PAYMENT-SERVICE/payment/doPayment", payment,
				Payment.class);
		resp = response.getPaymentStatus().equals("success") ? "payment processing successful and order placed"
				: "Payment failed and order is added at the cart.";
		repository.save(order);

		return new TransactionResponse(order, response.getAmount(), response.getTransactionId(), resp);
	}

}
